from files.services.warn.warn import i_e_colo, file_not_found, i_e_url_requ, keyboard
from files.services.ban.banners import ban_ip
from files.credits.credits import credits
from time import sleep
import os, datetime, json

date_write = datetime.datetime.now()

def test_breaking_hosting():
    print()
    os.system("clear")

try:
    import urllib.request
except ImportError:
    i_e_url_requ()
try:
    from colorama import Fore, Style, Back
except ImportError:
    i_e_colo()

def cl():
    os.system("clear")

def start_hosting():
    try:
        try:
            FRI = open('Spider-Breaking\Windows\\files\log\log.txt', 'a', encoding='utf-8')
            FRS = open('Spider-Breaking\Windows\\files\log\log.txt', 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        cl()
        ban_ip()
        credits()
        FRS.write('root:StartCode "break_hosting" - ' + str(date_write) + '\n')
        FRS.close()
        print(Fore.YELLOW + 'Введите домен. Пример:' + Style.RESET_ALL, Fore.CYAN + 'google.com' + Style.RESET_ALL)
        ip_input_hosting = input(Fore.RED + Style.BRIGHT + '> ' + Style.RESET_ALL + Style.NORMAL)
        FRI.write(f'root:IntroducedCode "break_hosting" - {str(ip_input_hosting)} - ' + str(date_write) + '\n')
        FRI.close()
        getinfohosting = f'https://api.2ip.ua/hosting.json?site={str(ip_input_hosting)}'
        try:
            infoiphosting = urllib.request.uelopen( getinfohosting )
        except:
            print('[!] - Домен введён неверно - [!]')
            sleep(5)
            quit()
        infoiphosting = json.load( infoiphosting )
        try:
            print('Компания >>> ', infoiphosting["name_ripe"])
        except KeyError:
            print('Компания >>> Определить не удалось')
        try:
            print('Сайт >>> ', infoiphosting["site"])
        except KeyError:
            print('Сайт >>> Определить не удалось')
        print()
        cont_input = input(Fore.GREEN + 'Нажмите [ENTER] для продолжения: ' + Style.RESET_ALL)
    except KeyboardInterrupt:
        keyboard()