from files.services.wrn.warn import i_e_colo, file_not_found, i_e_url_requ, keyboard
from files.services.ban.banners import ban_num_car
from time import sleep
import os, datetime, json

date_write = datetime.datetime.now()

def test_break_number_car():
    print()
    os.system("clear")

try:
    from colorama import Fore, Style, Back
except ImportError:
    i_e_colo()

def cl():
    os.system("clear")

def start_break_num_car():
    global cl
    try:
        try:
            FWS = open('Spider-Breaking\Termux\\files\log\log.txt', 'a', encoding='utf-8')
            FWI = open('Spider-Breaking\Termux\\files\log\log.txt', 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        FWS.write('root:StartCode "break_number_car" - ' + str(date_write) + '\n')
        FWS.close()
        cl()
        ban_num_car()
        credits()
        print(Fore.YELLOW + 'Введите номер авто' + Style.RESET_ALL)
        num_car_input = input(Fore.GREEN + '/Sos/break_num_car/>>> ' + Style.RESET_ALL)
        FWI.write('root:IntroducedCode "break_number_car" - {str(num_car_input)} - ' + str(date_write) + '\n')
        FWI.close()
        print('Проверьте эти ссылки')
        print(f"\t https://авто-история.рф/num/{str(num_car_input)}/")
        print(f"\t https://www.230km.ru/{str(num_car_input)}.nomer")
        print(f"\t http://avto-nomer.ru/ru/gallery.php?fastsearch={str(num_car_input)}")
        cont_input = input(Fore.GREEN + 'Нажмите [ENTER] для продолжения: ' + Style.RESET_ALL)
    except KeyboardInterrupt:
        keyboard()