from files.services.wrn.warn import i_e_colo, file_not_found, i_e_url_requ, keyboard
from files.services.ban.banners import ban_ip
from time import sleep
import os, datetime, json

date_write = datetime.datetime.now()

def test_break_mac():
    print()
    os.system("clear")

try:
    import urllib.request
except ImportError:
    i_e_url_requ()
try:
    from colorama import Fore, Style, Back
except ImportError:
    i_e_colo()

def cl():
    os.system("clear")

def start_mac():
    try:
        try:
            FRI = open('IP-System\\files\log\log.txt', 'a', encoding='utf-8')
            FRS = open('IP-System\\files\log\log.txt', 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        FRS.write('root:StartCode "break_mac" - ' + str(date_write) + '\n')
        FRS.close()
        print(Fore.YELLOW + 'Введите MAC-адрес. Пример:' + Style.RESET_ALL, Fore.CYAN + '00:30:48:5a:58:65' + Style.RESET_ALL)
        ip_input_mac = input(Fore.RED + Style.BRIGHT + '> ' + Style.RESET_ALL + Style.NORMAL)
        FRI.write(f'root:IntroducedCode "break_mac" - {str(ip_input_mac)} - ' + str(date_write) + '\n')
        FRI.close()
        getinfomac = f'https://api.2ip.ua/mac.json?mac={str(ip_input_mac)}'
        try:
            infoipmac = urllib.request.urlopen( getinfomac )
        except:
            print('[!] - MAC-адрес введён неверно - [!]')
            sleep(5)
            quit()
            infoipmac = json.load( infoipmac )
        try:
            print('Страна >>> ', infoipmac["country"])
        except KeyError:
            print('Страна >>> Определить не удалось')
        try:
            print('Компания >>> ', infoipmac["company"])
        except KeyError:
            print('Компания >>> Определить не удалось')
        try:
            print('Адрес >>> ', infoipmac["address"])
        except KeyError:
            print('Адрес >>> Определить не удалось')
        try:
            print('Дата создание MAC-адреса >>> ', infoipmac["date_created"])
        except KeyError:
            print('Дата создание MAC-адреса >>> Определить не удалось')
        try:
            print('Дата обновления MAC-адреса >>> ', infoipmac["date_updated"])
        except KeyError:
            print('Дата обновления MAC-адреса >>> Определить не удалось')
        print()
        cont_input = input(Fore.GREEN + 'Нажмите [ENTER] для продолжения: ' + Style.RESET_ALL)
    except KeyboardInterrupt:
        keyboard()