from rest import main
from rest.wrn import warn
import datetime

date_time_write = datetime.datetime.now()

fileRecordStart = open('rest/log/log_start.txt', 'a', encoding='utf-8')

try:
    try:
        fileRecordStart.write('# 0000-00-00 <--- Год, месяц, день 00:00:00.000000 <--- Час, минуты, секунды, милисекунды\n'
        'Start C-de - ' + str(date_time_write) + '\n\n')
        fileRecordStart.close()
        main.start()
    except FileNotFoundError:
        warn.file_not_found_error()
except KeyboardInterrupt:
    warn.keyboard_interrupt()