from files.services.wrn.warn import i_e_colo, file_not_found, i_e_url_requ, keyboard
from files.services.ban.banners import ban_ip
from time import sleep
import os, datetime, json

date_write = datetime.datetime.now()

def test_break_ip():
    print()
    os.system("clear")

try:
    import urllib.request
except ImportError:
    i_e_url_requ()
try:
    from colorama import Fore, Style, Back
except ImportError:
    i_e_colo()

def cl():
    os.system("clear")

def start_ip():
    global cl
    try:
        try:
            FRI = open('Spider-Breaking\Termux\\files\log\log.txt', 'a', encoding='utf-8')
            FRS = open('Spider-Breaking\Termux\\files\log\log.txt', 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        FRS.write('root:StartCode "break_ip" - ' + str(date_write) + '\n')
        FRS.close()
        cl()
        ban_ip()
        credits()
        print(Fore.YELLOW + 'Введите IP-адрес' + Style.RESET_ALL)
        ip_input = input(Fore.RED + Style.BRIGHT + '> ' + Style.RESET_ALL + Style.NORMAL)
        FRI.write(f'root:IntroducedCode "break_ip" - {str(ip_input)} - ' + str(date_write) + '\n')
        FRI.close()
        getinfoip = f'https://ipinfo.io/{str(ip_input)}/json'
        try:
            infoIp = urllib.request.urlopen( getinfoip )
        except:
            print('[!] - IP-адрес введён не верно - [!]')
            sleep(5)
            quit()
        infoIp = json.load( infoIp )
        try:
            print('Страна >>> ', infoIp["country"])
        except KeyError:
            print('Страна >>> Определить не удалось')
        try:
            print('Город >>> ', infoIp["city"])
        except KeyError:
            print('Город >>> Определить не удалось')
        try:
            print('Широта и долгота города >>> ', infoIp["loc"])
        except KeyError:
            print('Широта и долгота города >>> Определить не удалось')
        try:
            print('Название сети >>> ', infoIp["hostname"])
        except KeyError:
            print('Название сети >>> Определить не удалось')
        try:
            print('Провайдер >>> ', infoIp["org"])
        except KeyError:
            print('Провайдер >>> Определить не удалось')
        print()
        cont_input = input(Fore.GREEN + 'Нажмите [ENTER] для продолжения: ' + Style.RESET_ALL)
    except KeyboardInterrupt:
        keyboard()