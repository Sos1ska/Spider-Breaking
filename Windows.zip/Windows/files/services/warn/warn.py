import datetime, os, time

date_write = datetime.datetime.now()

def test_warn():
    print()
    os.system("cls")

def keyboard():
    FWW = open('Spider-Breaking\Windows(cons)\\files\log\log.txt', 'a', encoding='utf-8')
    FWW.write('root:Warning "KeyboardInterrupt" - ' + str(date_write) + '\n')
    FWW.close()
    print('\nСохранено по пути Spider-Breaking/Windows(cons)/files/log/log.txt')
    time.sleep(5)
    quit()

def file_not_found():
    try:
        FWE = open('Spider-Breaking\Windows(cons)\\files\log\log.txt', 'a', encoding='utf-8')
    except FileNotFoundError:
        FWE1 = open('Spider-Breaking\Windows(cons)\\files\error.txt', 'a', encoding='utf-8')
        FWE1.write('root:Error "FileNotFoundError" - ' + str(date_write) + '\n')
        FWE1.close()
        print('\nСохранено по пути Spider-Breaking/Windows(cons)/files/error.txt')
        time.sleep(5)
        quit()
    FWE.write('root:Error "FileNotFoundError" - ' + str(date_write) + '\n')
    FWE.close()
    print('\nСохранено по пути Spider-Breaking/Windows(cons)/files/log/log.txt')
    time.sleep(5)
    quit()

def i_e_colo():
    FWE = open('Spider-Breaking\Windows(cons)\\files\log\log.txt', 'a', encoding='utf-8')
    FWE.write('root:ImportError "Colorama" - ' + str(date_write) + '\n')
    FWE.close()
    print('\nСохранено по пути Spider-Breaking/Windows(cons)/files/log/log.txt')
    time.sleep(5)
    quit()

def i_e_url_requ():
    FWE = open('Spider-Breaking\Windows(cons)\\files\log\log.txt', 'a', encoding='utf-8')
    FWE.write('root:ImportError "Requests" - ' + str(date_write) + '\n')
    FWE.close()
    print('\nСохранено по пути Spider-Breaking/Windows(cons)/files/log/log.txt')
    time.sleep(5)
    quit()

def i_e_url3():
    FWE = open('Spider-Breaking\Windows(cons)\\files\log\log.txt', 'a', encoding='utf-8')
    FWE.write('root:ImportError "Urllib3" - ' + str(date_write) + '\n')
    FWE.close()
    print('\nСохранено по пути Spider-Breaking/Windows(cons)/files/log/log.txt')
    time.sleep(5)
    quit()
