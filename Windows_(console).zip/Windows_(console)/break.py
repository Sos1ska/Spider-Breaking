from files.errors import warn
from files import main
import datetime

fileRecordError = open('Windows_(console)/files/services/log/log_error.txt', 'a', encoding='utf-8')

try:
    try:
        try:
            try:
                try:
                    try:
                        try:
                            datetime_write = datetime.datetime.now()
                            fileRecordStart = open('Windows_(console)/files/services/log/log_start.txt', 'a', encoding='utf-8')
                            fileRecordStart.write('# 0000-00-00 <--- Год, месяц, день 00:00:00.000000 <--- Час, минуты, секунды, милисекунды\n'
                            'Started C-de - ' + str(datetime_write) + '\n\n')
                            fileRecordStart.close()
                            main.start()
                        except FileNotFoundError:
                            warn.file_not_found_error()
                            fileRecordError.write('# 0000-00-00 <--- Год, месяц, день 00:00:00.000000 <--- Час, минуты, секунды, милисекунды\n'
                            'Error - FileNotFoundError - ' + str(datetime_write) + '\n\n')
                    except MemoryError:
                        warn.Memory_Error()
                        fileRecordError.write('# 0000-00-00 <--- Год, месяц, день 00:00:00.000000 <--- Час, минуты, секунды, милисекунды\n'
                        'Error - MemoryError - ' + str(datetime_write) + '\n\n')
                except SystemExit:
                    warn.System_Exit()
                    fileRecordError.write('# 0000-00-00 <--- Год, месяц, день 00:00:00.000000 <--- Час, минуты, секунды, милисекунды\n'
                    'Error - SystemExit - ' + str(datetime_write) + '\n\n')
            except SyntaxWarning:
                warn.Syntax_Warning()
                fileRecordError.write('# 0000-00-00 <--- Год, месяц, день 00:00:00.000000 <--- Час, минуты, секунды, милисекунды\n'
                'Error - SyntaxWarning - ' + str(datetime_write) + '\n\n')
        except SyntaxError:
            warn.Syntax_Error()
            fileRecordError.write('# 0000-00-00 <--- Год, месяц, день 00:00:00.000000 <--- Час, минуты, секунды, милисекунды\n'
            'Error - SyntaxError - ' + str(datetime_write) + '\n\n')
    except SystemError:
        warn.System_Error()
        fileRecordError.write('# 0000-00-00 <--- Год, месяц, день 00:00:00.000000 <--- Час, минуты, секунды, милисекунды\n'
        'Error - SystemError - ' + str(datetime_write) + '\n\n')
except KeyboardInterrupt:
    warn.keyboard_interrupt()
    fileRecordError.write('# 0000-00-00 <--- Год, месяц, день 00:00:00.000000 <--- Час, минуты, секунды, милисекунды\n'
    'Error - KeyboardInterrupt' + str(datetime_write) + '\n\n')

fileRecordError.close()