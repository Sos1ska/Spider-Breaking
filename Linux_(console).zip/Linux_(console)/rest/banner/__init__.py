# Создатель ---> https://vk.com/nikitasos1ska
# Помощь в создании ---> https://vk.com/2pac_jdm, https://vk.com/paket20, https://vk.com/covidone

# github профили ---> https://github.com/Sos1ska, https://github.com/Cool-Hackers, https://github.com/Ki11sesh

# Данный код защищён лицензией ---> GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
# Можете прочесть данную лицензию по пути Unix (console)/rest/licenses.txt