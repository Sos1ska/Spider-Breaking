from.credits import credits
from.errors import warn
from.ban import banners
from time import sleep
import os, json 

def cl():
    os.system("cls")

try:
    import requests
except ImportError:
    warn.Import_Error_Reuqests()
try:
    import urllib.request
except ImportError:
    warn.Import_Error_Reuqests()
try:
    from colorama import Fore, Style, Back
except ImportError:
    warn.Import_Error_Colorama()
try:
    import urllib3
except ImportError:
    warn.Import_Error_Urllib3()

red = '\033[91m'
green = '\033[92m'
end = '\033[0m'

def break_num():
    try:
        cl()
        banners.ban_num_services()
        print()
        credits.credits_services()
        print(Fore.YELLOW + 'Введите номер телефона Пример:' + Style.RESET_ALL, Fore.CYAN + '+79515200611' + Style.RESET_ALL)
        number_input = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_num/>>> ' + Style.RESET_ALL + Style.NORMAL)
        getinfonum = f'https://htmlweb.ru/geo/api.php?json&telcod={str(number_input)}'
        try:
            infoNumber = urllib.request.urlopen( getinfonum )
        except:
            print('[!] - Номер введён неверно - [!]')
            sleep(5)
            quit()
        infoNumber = json.load( infoNumber )
        try:
            print(f"{green}[✓]{end} - Страна >>> ", infoNumber["country"]["fullname"])
        except KeyError:
            print(f"{red}[✘]{end} - Cтрана >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Столица >>> ", infoNumber["capital"]["name"])
        except KeyError:
            print(f"{red}[✘]{end} - Столица >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Широта столицы >>> ", infoNumber["capital"]["latitude"])
        except KeyError:
            print(f"{red}[✘]{end} - Широта столицы >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Долгота столицы >>> ", infoNumber["capital"]["longitude"])
        except KeyError:
            print(f"{red}[✘]{end} - Долгота столицы >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Тип времени >>> +", infoNumber["capital"]["time_zone"])
        except KeyError:
            print(f"{red}[✘]{end} - Тип времени >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Код номера >>> ", infoNumber["country"]["country_code3"])
        except KeyError:
            print(f"{red}[✘]{end} - Код номера >>> Не удалось опеределить")
        try:
            print(f"{green}[✓]{end} - MCC номера >>> ", infoNumber["country"]["mcc"])
        except KeyError:
            print(f"{red}[✘]{end} - MCC номера >>> Не удалось оперделить")
        try:
            print(f"{green}[✓]{end} - Регион >>> ", infoNumber["region"]["name"])
        except KeyError:
            print(f"[✘] - Регион >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Округ >>> ", infoNumber["region"]["okrug"])
        except KeyError:
            print(f"{red}[✘]{end} - Округ >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Код региона >>> ", infoNumber["region"]["autocod"])
        except KeyError:
            print(f"{red}[✘]{end} - Код региона >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Город >>> ", infoNumber["0"]["name"])
        except KeyError:
            print(f"{red}[✘]{end} - Город >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Широта города >>> ", infoNumber["0"]["latitude"])
        except KeyError:
            print(f"{red}[✘]{end} - Широта города >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Долгота города >>> ", infoNumber["0"]["longitude"])
        except KeyError:
            print(f"{red}[✘]{end} - Долгота города >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Oper_id >>> ", infoNumber["0"]["oper_id"])
        except KeyError:
            print(f"{red}[✘]{end} - Oper_id >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Радиус номеров телефонов >>> ", infoNumber["0"]["def"])
        except KeyError:
            print(f"{red}[✘]{end} - Радиус номеров телефоно >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Рабочесть телефона >>> ", infoNumber["0"]["mobile"])
        except KeyError:
            print(f"{red}[✘]{end} - Рабочесть телефона >>> Не удалось определить")
        try:
            print(f"{green}[✓]{end} - Оператор >>> ", infoNumber["0"]["oper"])
        except KeyError:
            print(f"{red}[✘]{end} - Оператор >>> Не удалось определить")
        print()
        print(Fore.YELLOW + f"Проверьте эти ссылки: " + Style.RESET_ALL)
        print(f"https://api.whatsapp.com/send?phone={str(number_input)}&text=You,%20are&20hacked%20by%20by%20the%20Cool-Hackers - Поиск номера в", Fore.GREEN + "WhatsApp" + Style.RESET_ALL) 
        print(f"https://facebook.com/login/identify/?ctx=recover&ars=royal_blue_bar - Поиск номера в", Fore.BLUE + "Facebook" + Style.RESET_ALL)
        print(f"https://linkedin.com/checkpoint/rp/request-password-reset-submit - Поиск номера в Linkedin")
        print(f"https://viber://add?number={str(number_input)} - Поиск номера в", Fore.MAGENTA + "Viber" + Style.RESET_ALL)
        print(f"https://skype:{str(number_input)}?call - Звонок через", Fore.BLUE + "Skype" + Style.RESET_ALL)
        print(f"tel:{str(number_input)} - Простой звонок")
        print()
        print(Fore.YELLOW + "Вставьте эту ссылку в браузер с поисковой системой" + Style.RESET_ALL, f"{red}Y{end}andex: ")
        print(f"site:vk.com {str(number_input)} - Поиск номера по сайту", Fore.BLUE + "VK" + Style.RESET_ALL)
        print(f"site:ok.ru {str(number_input)} - Поиск номера по сайту", Fore.YELLOW + "OK" + Style.RESET_ALL)
        print(f"site:instagram.com {str(number_input)} - Поиск номера по сайту Instagram")
        print()
        print(Fore.YELLOW + 'Предоставить доступ к сот. вышкам? Надо запомнить Долготу и широту города' + Style.RESET_ALL)
        print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
        while True:
            cell_tower = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_num/>>> ' + Style.RESET_ALL + Style.NORMAL)
            if str(cell_tower) == "y":
                cl()
                banners.ban_num_services()
                latitude_tower_input = input(Fore.YELLOW + "Введите широту: " + Style.RESET_ALL)
                longitude_tower_input = input(Fore.YELLOW + "Введите долготу: " + Style.RESET_ALL)
                print(Fore.YELLOW + f"Вставьте данную ссылку в любой браузер:\n" + Style.RESET_ALL)
                print(f"https://opencellid.org/#zoom=13&lat={str(latitude_tower_input)}&lon={str(longitude_tower_input)}")
                print(Fore.YELLOW + 'Продолжить?' + Style.RESET_ALL)
                print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
                while True:
                    cont_input_num = input(Fore.GREEN + '/Sos/break_num/cell_tower/>>> ' + Style.RESET_ALL)
                    if str(cont_input_num) == "y":
                        cl()
                    elif str(cont_input_num) == "n":
                        print(Fore.YELLOW + 'Произвести выход из кода?' + Style.RESET)
                        print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
                        while True:
                            exit_input = input(Fore.GREEN + Style.BRIGHT + '/Sos/search_nick/>>> ' + Style.RESET_ALL + Style.NORMAL)
                            if str(exit_input) == "y":
                                cl()
                                credits.credits_services()
                            elif str(exit_input) == "n":
                                cl()
                            else:
                                print(Fore.RED + Style.BRIGHT + 'Неккоретная команда' + Style.RESET_ALL + Style.NORMAL, f': {str(exit_input)}')
                    else:
                        print(Fore.RED + Style.BRIGHT + 'Неккоретная команда' + Style.RESET_ALL + Style.NORMAL, f': {str(cont_input_num)}')
            elif str(cell_tower) == "n":
                print(Fore.YELLOW + 'Произвести выход из кода?' + Style.RESET)
                print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
                while True:
                    exit_input = input(Fore.GREEN + Style.BRIGHT + '/Sos/search_nick/>>> ' + Style.RESET_ALL + Style.NORMAL)
                    if str(exit_input) == "y":
                        cl()
                        credits.credits_services()
                        quit()
                    elif str(cell_tower) == "n":
                        cl()
                    else:
                        print(Fore.RED + Style.BRIGHT + 'Неккоретная команда' + Style.RESET_ALL + Style.NORMLA, f': {str(exit_input)}')
            else:
                print(Fore.RED + Style.BRIGHT + 'Неккоретная команда' + Style.RESET_ALL + Style.NORMAL, f': {str(cell_tower)}')

    except KeyboardInterrupt:
        warn.keyboard_interrupt()