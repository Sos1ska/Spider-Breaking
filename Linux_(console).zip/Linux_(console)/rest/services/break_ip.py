from.banner import banners
from.wrn_services import warn
from.credits import credits
from time import sleep
import os, json

try:
    import requests
except ImportError:
    warn.Import_Error_Reuqests()
try:
    import urllib3
except ImportError:
    warn.Import_Error_Urllib3()
try:
    import urllib.request
except ImportError:
    warn.Import_Error_Requests
try:
    from colorama import Fore, Back, Style
except ImportError:
    warn.Import_Error_Colorama()

def cl():
    os.system("clear")

def start():
    try:
        cl()
        banners.ban_ip_services()
        credits.credits_services()
        ip_input = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_ip/>>> ' + Style.RESET_ALL + Style.NORMAL)

        getinfoip = f'https://ipinfo.io/{str(ip_input)}/json'
        try:
            infoIp = urllib.request.urlopen( getinfoip )
        except:
            print('[!] - IP-адрес введён не верно - [!]')
            sleep(5)
            quit()
        infoIp = json.load( infoIp )
        try:
            print('Страна >>> ', infoIp["country"])
        except KeyError:
            print('Страна >>> Определить не удалось')
        try:
            print('Город >>> ', infoIp["city"])
        except KeyError:
            print('Город >>> Определить не удалось')
        try:
            print('Широта и долгота города >>> ', infoIp["loc"])
        except KeyError:
            print('Широта и долгота города >>> Определить не удалось')
        try:
            print('Название сети >>> ', infoIp["hostname"])
        except KeyError:
            print('Название сети >>> Определить не удалось')
        try:
            print('Провайдер >>> ', infoIp["org"])
        except KeyError:
            print('Провайдер >>> Определить не удалось')
        print()
        print('Предоставить информацию о IP-адресе через хостинг 2ip.ua?')
        print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
        print()
        while True:
            second_break_ip = input(Fore.GREEN + Style.BRIGHT + "/Sos/break_ip/>>> " + Style.RESET_ALL + Style.NORMAL)
            if str(second_break_ip) == "y":
                cl()
                banners.ban_ip_services()
                credits.credits_services()
                print("Введите help чтобы увидеть доступные команды")
                print()
                while True:
                    second_ipp_input = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_ip/>>> ' + Style.RESET_ALL + Style.NORMAL)
                    if str(second_ipp_input) == "help":
                        banners.second_ip()
                    
                    elif str(second_ipp_input) == "break_ip_geo_location":
                        cl()
                        banners.ban_ip_services()
                        credits.credits_services()
                        print(Fore.YELLOW + 'Выберите тип IPv4/IPv6' + Style.RESET_ALL)
                        print(Fore.RED + 'Вводите маленькими буквами')
                        print()
                        while True:
                            type_ip_input = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_ip/break_ip_geo_location/>>> ' + Style.RESET_ALL + Style.NORMAL)
                            if str(type_ip_input) == "ipv4":
                                cl()
                                banners.ban_ip_services()
                                credits.credits_services()
                                print(Fore.YELLOW + 'Введите IP-адрес' + Style.RESET_ALL)
                                ip_ip4v_input = input (Fore.GREEN + Style.BRIGHT + '/Sos/break_ip/break_ip_gep_location/ipv4/>>> ' + Style.RESET_ALL + Style.NORMAL)

                                getinfoipua = f'https://api.2ip.ua/geo.json?ip={str(ip_ip4v_input)}'
                                try:
                                    infoipgeolocation = urllib.request.urlopen( getinfoipua )
                                except:
                                    print('[!] - IP-адрес введён неверно - [!]')
                                    sleep(5)
                                    quit()
                                infoipgeolocation = json.load( infoipgeolocation )
                                try:
                                    print('Страна >>> ', infoipgeolocation["country"])
                                except KeyError:
                                    print('Страна >>> Определить не удалось')
                                try:
                                    print('Регион >>> ', infoipgeolocation["region"])
                                except KeyError:
                                    print('Регион >>> Определить не удалось')
                                try:
                                    print('Город >>> ', infoipgeolocation["city"])
                                except KeyError:
                                    print('Город >>> Определить не удалось')
                                try:
                                    print('Широта города >>> ', infoipgeolocation["latitude"])
                                except KeyError:
                                    print('Широта города >>> Определить не удалось')
                                try:
                                    print('Долгота города >>> ', infoipgeolocation["longitude"])
                                except KeyError:
                                    print('Долгота города >>> Определить не удалось')
                                try:
                                    print('Почтовый индекс >>> ', infoipgeolocation["zip_code"])
                                except KeyError:
                                    print('Почтовый индекс >>> Определить не удалось')
                                try:
                                    print('Часовой пояс >>> ', infoipgeolocation["time_zone"])
                                except KeyError:
                                    print('Часовой пояс >>> Определить не удалось')
                                print()
                                print('Продолжить?')
                                print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
                                print()
                                while True:
                                    cont_input_ipv4 = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_ip/break_ip_geo_location/>>> ' + Style.RESET_ALL + Style.NORMAL)
                                    if str(cont_input_ipv4) == "n":
                                        cl()
                                        credits.credits_services()
                                        sleep(5)
                                        quit

                                    elif str(cont_input_ipv4) == "y":
                                        os.system("clear")
                                    else:
                                        print(Fore.RED + Style.BRIGHT + "Неккоретная команда" + Style.RESET_ALL + Style.NORMAL, f": {str(cont_input_ipv4)}")
                            
                            elif str(type_ip_input) == "ipv6":
                                cl()
                                banners.ban_ip_services()
                                credits.credits_services()
                                print(Fore.YELLOW + 'Введите IP-адрес' + Style.RESET_ALL)
                                ip_ipv6_input = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_ip/break_ip_geo_location/ipv6/>>> ' + Style.RESET_ALL + Style.NORMAL)

                                getinfoipuaipv6 = f'https://api.2ip.ua/geo.json?ip={str(ip_ipv6_input)}'
                                try:
                                    infoipgeolocationipv6 = urllib.request.urlopen( getinfoipuaipv6 )
                                except:
                                    print('[!] - IP-адрес введён не верно - [!]')
                                    sleep(5)
                                    quit()
                                infoipgeolocationipv6 = json.load( infoipgeolocationipv6 )
                                try:
                                    print('Страна >>> ', infoipgeolocationipv6["country"])
                                except KeyError:
                                    print('Страна >>> Определить не удалось')
                                try:
                                    print('Регион >>> ', infoipgeolocation  ["region"])
                                except KeyError:
                                    print('Регион >>> Определить не удалось')
                                try:
                                    print('Город >>> ', infoipgeolocation["city"])
                                except KeyError:
                                    print('Город >>> Определить не удалось')
                                try:
                                    print('Широта города >>> ', infoipgeolocation["latitude"])
                                except KeyError:
                                    print('Широта города >>> Определить не удалось')
                                try:
                                    print('Долгота города >>> ', infoipgeolocation["longitude"])
                                except KeyError:
                                    print('Долгота города >>> Определить не удалось')
                                try:
                                    print('Почтовый индекс >>> ', infoipgeolocation["zip_code"])
                                except KeyError:
                                    print('Почтовый индекс >>> Определить не удалось')
                                try:
                                    print('Часовой пояс >>> ', infoipgeolocation["time_zone"])
                                except KeyError:
                                    print('Часовой пояс >>> Определить не удалось')
                                print()
                                print('Продолжить?')
                                print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
                                print()
                                while True:
                                    cont_input_ipv6 = input(Fore.GREEN + '/Sos/break_ip/break_ip_geo_location/>>> ' + Style.RESET_ALL)
                                    if str(cont_input_ipv6) == "n":
                                        cl()
                                        credits.credits_services()
                                        sleep(5)
                                        quit
                                    
                                    elif str(cont_input_ipv6) == "y":
                                        os.system("clear")
                                    else:
                                        print(Fore.RED + Style.BRIGHT + "Неккоретная команда" + Style.RESET_ALL + Style.NORMAL, f": {str(cont_input_ipv6)}")

                            else:
                                print(Fore.RED + Style.BRIGHT + "Неккоретная команда" + Style.RESET_ALL + Style.NORMAL, f": {str(type_ip_input)}")
                    
                    elif str(second_ipp_input) == "break_ip_ISP":
                        cl()
                        banners.ban_ip_services()
                        credits.credits_services()
                        print(Fore.YELLOW + 'Введите IP-адрес' + Style.RESET_ALL)
                        ip_input_isp = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_ip/break_ip_ISP/>>> ' + Style.RESET_ALL + Style.NORMAL)

                        getinfoipisp = f' https://api.2ip.ua/provider.json?ip={str(ip_input_isp)}'
                        try:
                            infoipisp = urllib.request.urlopen( getinfoipisp )
                        except:
                            print('[!] - IP-адрес введён неверно - [!]')
                            sleep(5)
                            quit()
                        infoipisp = json.load( infoipisp )
                        try:
                            print('Провайдер >>> ', infoipisp["name_ripe"])
                        except KeyError:
                            print('Провайдер >>> Определить не удалось')
                        try:
                            print('Сайт провайдера >>> ', infoipisp["site"])
                        except KeyError:
                            print('Сайт провайдера >>> Определить не удалось')
                        try:
                            print('Начало диапозона IP-адерса ', infoipisp["ip_range_start"])
                        except KeyError:
                            print('Начало диапозона IP-адреса >>> Определить не удалось')
                        try:
                            print('Окончание диапозона IP-адреса >>> ', infoipisp["ip_range_end"])
                        except KeyError:
                            print('Окончание диапозона IP-адреса >>> Определить не удалось')
                        try:
                            print('IP-машрут >>> ', infoipisp["route"])
                        except KeyError:
                            print('IP-машрут >>> Определить не удалось')
                        try:
                            print('Маска >>> ', infoipisp["mask"])
                        except KeyError:
                                print('Маска >>> Определить не удалось')
                        print()
                        print('Продолжить?')
                        print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
                        print()
                        while True:
                            cont_input_isp = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_ip/break_ip_ISP/>>> ' + Style.RESET_ALL + Style.NORMAL)
                            if str(cont_input_isp) == "n":
                                cl()
                                credits.credits_services()
                                sleep(5)
                                quit()
                            elif str(cont_input_isp) == "y":
                                os.system("clear")
                            else:
                                print(Fore.RED + Style.BRIGHT + "Неккоретная команда" + Style.RESET_ALL + Style.NORMAL, f": {str(cont_input_isp)}")
                    
                    elif str(second_ipp_input) == "break_ip_mac":
                        cl()
                        banners.ban_ip_services()
                        credits.credits_services()
                        print(Fore.YELLOW + 'Введите MAC-адрес. Пример:' + Style.RESET_ALL, Fore.CYAN + '00:30:48:5a:58:65' + Style.RESET_ALL)
                        ip_input_mac = input(Fore.GREEN + '/Sos/break_ip/break_ip_mac/>>> ' + Style.RESET_ALL)

                        getinfomac = f'https://api.2ip.ua/mac.json?mac={str(ip_input_mac)}'
                        try:
                            infoipmac = urllib.request.urlopen( getinfomac )
                        except:
                            print('[!] - MAC-адрес введён неверно - [!]')
                            sleep(5)
                            quit()
                        infoipmac = json.load( infoipmac )
                        try:
                            print('Страна >>> ', infoipmac["country"])
                        except KeyError:
                            print('Страна >>> Определить не удалось')
                        try:
                            print('Компания >>> ', infoipmac["company"])
                        except KeyError:
                            print('Компания >>> Определить не удалось')
                        try:
                            print('Адрес >>> ', infoipmac["address"])
                        except KeyError:
                            print('Адрес >>> Определить не удалось')
                        try:
                            print('Дата создание MAC-адреса >>> ', infoipmac["date_created"])
                        except KeyError:
                            print('Дата создание MAC-адреса >>> Определить не удалось')
                        try:
                            print('Дата обновления MAC-адреса >>> ', infoipmac["date_updated"])
                        except KeyError:
                            print('Дата обновления MAC-адреса >>> Определить не удалось')
                        print()
                        print('Продолжить?')
                        print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
                        while True:
                            cont_ip_mac = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_ip/break_ip_mac/>>> ' + Style.RESET_ALL + Style.NORMAL)
                            if str(cont_ip_mac) == "n":
                                cl()
                                credits.credits_services()
                                sleep(5)
                                quit()

                            elif str(cont_ip_mac) == "y":
                                os.system("clear")
                            else:
                                print(Fore.RED + Style.BRIGHT + "Неккоретная команда" + Style.RESET_ALL + Style.NORMAL, f": {str(cont_ip_mac)}")

                    elif str(second_ipp_input) == "break_ip_hosting":
                        cl()
                        banners.ban_ip_services()
                        credits.credits_services()
                        print(Fore.YELLOW + 'Введите домен. Пример:' + Style.RESET_ALL, Fore.CYAN + 'google.com' + Style.RESET_ALL)
                        ip_input_hosting = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_ip/break_ip_hosting/>>> ' + Style.RESET_ALL + Style.NORMAL)

                        getinfohosting = f'https://api.2ip.ua/hosting.json?site={str(ip_input_hosting)}'
                        try:
                            infoiphosting = urllib.request.uelopen( getinfohosting )
                        except Exception:
                            print('[!] - Домен введён неверно - [!]')
                            sleep(5)
                            quit()
                        infoiphosting = json.load( infoiphosting )
                        try:
                            print('Компания >>> ', infoiphosting["name_ripe"])
                        except KeyError:
                            print('Компания >>> Определить не удалось')
                        try:
                            print('Сайт >>> ', infoiphosting["site"])
                        except KeyError:
                            print('Сайт >>> Определить не удалось')
                        print()
                        print('Продолжить?')
                        print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
                        while True:
                            cont_ip_hosting = input(Fore.GREEN + Style.BIRGHT + '/Sos/break_ip/break_ip_hosting/>>> ' + Style.RESET_ALL + Style.NORMAL)
                            if str(cont_ip_hosting) == "n":
                                cl()
                                credits.credits_services()
                                sleep(5)
                                quit()

                            elif str(cont_ip_hosting) == "y":
                                os.system("clear")
                            else:
                                print(Fore.RED + Style.BRIGHT + "Неккоретная команда" + Style.RESET_ALL + Style.NORMAL, f": {str(cont_ip_hosting)}")
                    else:
                        print(Fore.RED + Style.BRIGHT + "Неккоретная команда" + Style.RESET_ALL + Style.NORMAL, f": {str(second_ipp_input)}")

            elif str(second_break_ip) == "n":
                os.system("clear")
            else:
                print(Fore.RED + Style.NORMAL + "Неккоретная команда" + Style.RESET_ALL + Style.NORMAL, f": {str(second_break_ip)}")
    except KeyboardInterrupt:
        warn.keyboard_interrupt()