from files.services.warn.warn import i_e_colo, file_not_found, i_e_url_requ, keyboard
from files.services.ban.banners import ban_ip
from time import sleep
import os, datetime, json

date_write = datetime.datetime.now()

def test_break_isp():
    print()
    os.system("clear")

try:
    import urllib.request
except ImportError:
    i_e_url_requ()
try:
    from colorama import Fore, Style, Back
except ImportError:
    i_e_colo()

def cl():
    os.system("clear")

def start_isp():
    try:
        try:
            FRI = open('Spider-Breaking\Windows\\files\log\log.txt', 'a', encoding='utf-8')
            FRS = open('Spider-Breaking\Windows\\files\log\log.txt', 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        FRS.write('root:StartCode "break_hosting" - ' + str(date_write) + '\n')
        FRS.close()
        cl()
        print(Fore.YELLOW + 'Введите IP-адрес' + Style.RESET_ALL)
        ip_input_isp = input(Fore.RED + Style.BRIGHT + '> ' + Style.RESET_ALL + Style.NORMAL)
        FRI.write('root:IntroducedCode "break_hosting" - ' + str(date_write) + '\n')
        FRI.close()
        getinfoipisp = f' https://api.2ip.ua/provider.json?ip={str(ip_input_isp)}'
        try:
            infoipisp = urllib.request.urlopen( getinfoipisp )
        except:
            print('[!] - IP-адрес введён неверно - [!]')
            sleep(5)
            quit()
        infoipisp = json.load( infoipisp )
        try:
            print('Провайдер >>> ', infoipisp["name_ripe"])
        except KeyError:
            print('Провайдер >>> Определить не удалось')
        try:
            print('Сайт провайдера >>> ', infoipisp["site"])
        except KeyError:
            print('Сайт провайдера >>> Определить не удалось')
        try:
            print('Начало диапозона IP-адерса ', infoipisp["ip_range_start"])
        except KeyError:
            print('Начало диапозона IP-адреса >>> Определить не удалось')
        try:
            print('Окончание диапозона IP-адреса >>> ', infoipisp["ip_range_end"])
        except KeyError:
            print('Окончание диапозона IP-адреса >>> Определить не удалось')
        try:
            print('IP-машрут >>> ', infoipisp["route"])
        except KeyError:
            print('IP-машрут >>> Определить не удалось')
        try:
            print('Маска >>> ', infoipisp["mask"])
        except KeyError:
            print('Маска >>> Определить не удалось')
        print()
        cont_input = input(Fore.GREEN + 'Нажмите [ENTER] для продолжения: ' + Style.RESET_ALL)
    except KeyboardInterrupt:
        keyboard()