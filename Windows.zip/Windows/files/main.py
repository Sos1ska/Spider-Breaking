import datetime
import os
import time

from files.help.help import help_menu
from files.services.ban.banners import started_ban, started_code
from files.services.break_cell import start_cell
from files.services.break_hosting import start_hosting
from files.services.break_ip import start_ip
from files.services.break_isp import start_isp
from files.services.break_mac import start_mac
from files.services.break_num import start_num
from files.services.break_number_car import start_break_num_car
from files.credits.credits import credits
from files.services.search_nick import search_nick
from files.services.warn.warn import (file_not_found, i_e_colo, i_e_url3,
                                      i_e_url_requ, keyboard)

try:
    from colorama import Back, Fore, Style
except ImportError:
    i_e_colo()
try:
    import requests
except ImportError:
    i_e_url_requ()
try:
    import urllib3
except ImportError:
    i_e_url3()

def test_main():
    print()
    os.system("cls")

def cl():
    os.system("cls")

def start_main():
    global cl
    try:
        try:
            FWS = open('Spider-Breaking\Windows\\files\log\log.txt', 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        cl()
        started_code()
        while True:
            cl()
            started_ban()
            credits()
            while True:
                menu = input(Fore.RED + '> ' + Style.RESET_ALL)
                if str(menu) == "help":
                    help_menu()
                elif str(menu) == "break_num":
                    start_num()
                elif str(menu) == "break_num_car":
                    start_break_num_car()
                elif str(menu) == "break_mac":
                    start_mac()
                elif str(menu) == "break_isp":
                    start_isp()
                elif str(menu) == "break_ip":
                    start_ip()
                elif str(menu) == "break_cell":
                    start_cell()
                elif str(menu) == "break_hosting":
                    start_hosting()
                elif str(menu) == "search_nick":
                    search_nick()
                else:
                    print(Fore.RED + Style.BRIGHT + 'Неккоретная команда' + Style.RESET_ALL + Style.NORMAL, f": {str(menu)}")
    except KeyboardInterrupt:
        keyboard()
