from.services import break_num, break_ip, break_num_car, search_nick, spy_vk
from.wrn import warn
from.banner import ban
from.help_input import help_go
from.credits import credits
from time import sleep
import os

def cl():
    os.system("clear")

try:
    from colorama import Fore, Style, Back
except ImportError:
    warn.Import_Error_Colorama()

def start():
    try:
        cl()
        ban.start_code()
        cl()
        ban.main_banner()
        help_go.help()
        while True:
            services = input(Fore.GREEN + Style.BRIGHT + '/Sos/>>> ' + Style.RESET_ALL + Style.NORMAL)
            if str(services) == "break_num":
                break_num.start()
            elif str(services) == "break_num_car":
                break_num_car.start()
            elif str(services) == "search_nick":
                search_nick.start()
            elif str(services) == "break_ip":
                break_ip.start()
            elif str(services) == "spy_vk":
                spy_vk.start()
            else:
                print(Fore.RED + Style.BRIGHT + 'Неккоретная команда' + Style.NORMAL + Style.RESET_ALL, f': {str(services)}')
    except KeyboardInterrupt:
        warn.keyboard_interrupt()