import datetime
import os

from files.main import start_main
from files.test.test import start_test
from files.services.warn.warn import keyboard, file_not_found

date_write = datetime.datetime.now()

def cl():
    os.system("cls")

try:
    try:
        FWS = open('Spider-Breaking\Windows\\files\log\log.txt', 'a', encoding='utf-8')
    except FileNotFoundError:
        file_not_found()
    FWS.write('root:StartCode "Spider-Breaking" - ' + str(date_write) + '\n')
    FWS.close()
    cl()
    start_test()
    cl()
    start_main()
except KeyboardInterrupt:
    keyboard()