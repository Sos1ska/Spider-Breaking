from.credits import credits
from.wrn_services import warn
from.banner import banners
from time import sleep
import os

def cl():
    os.system("clear")

try:
    import requests
except ImportError:
    warn.Import_Error_Reuqests()
try:
    import urllib.request
except ImportError:
    warn.Import_Error_Reuqests()
try:
    from colorama import Fore, Style, Back
except ImportError:
    warn.Import_Error_Colorama()
try:
    import urllib3
except ImportError:
    warn.Import_Error_Urllib3()  
    
def start():
    try:
        cl()
        banners.ban_search_nick()
        credits.credits_services()
        print(Fore.YELLOW + 'Введите никнейм' + Style.RESET_ALL)
        nick = input(Fore.GREEN + Style.BRIGHT + '/Sos/search_nick/>>> ' + Style.RESET_ALL + Style.NORMAL)
        urls_site = ["https://my.mail.ru/mail/",
                    "https://www.drive2.ru/users/",
                    "https://twitter.com/",
                    "https://github.com/",
                    "https://instagram.com/"
                    "http://forum.3dnews.ru/member.php?username=",
                    "https://4pda.ru/forum/index.php?act=search&source=pst&noform=1&username=",
                    "https://forums.adobe.com/people/",
                    "https://ask.fm/",
                    "https://badoo.com/profile/",
                    "https://www.bandcamp.com/",
                    "https://bitcoinforum.com/profile/",
                    "blogspot.com",
                    "https://dev.to/",
                    "https://www.ebay.com/usr/",
                    "https://www.gamespot.com/profile/",
                    "https://ok.ru/",
                    "https://play.google.com/store/apps/developer?id=",
                    "https://pokemonshowdown.com/users/",
                    "https://www.reddit.com/user/",
                    "https://steamcommunity.com/id/",
                    "https://steamcommunity.com/groups/",
                    "https://tamtam.chat/",
                    "https://t.me/",
                    "https://www.tiktok.com/@",
                    "https://www.twitch.tv/",
                    "https://data.typeracer.com/pit/profile?user=",
                    "https://www.wikipedia.org/wiki/User:",
                    "https://yandex.ru/collections/user/",
                    "https://www.youtube.com/",
                    "https://www.baby.ru/u/",
                    "https://www.babyblog.ru/user/info/",
                    "https://www.geocaching.com/profile/?u=",
                    "https://habr.com/ru/users/",
                    "https://pikabu.ru/@",
                    "https://spletnik.ru/user/",
                    "https://www.facebook.com/",
                    "hhttps://zen.yandex.ru/",
                    "https://ggscore.com/ru/dota-2/player?t=",
                    "https://www.facebook.com/public/"]
        set_i = 0
        print("\033[35m|   |_\033[0m")
        while True:
            try:
                if set_i==13:
                    scan_s = requests.get("https://"+nick+"."+urls_site[set_i])
                else:
                    scan_s = requests.get(urls_site[set_i]+""+nick)

                if scan_s:
                    if set_i==13:
                            print("\033[35m|     |- https://"+nick+"."+urls_site[set_i]+"\033[0m")
                    else:
                        print("\033[35m|     |- "+urls_site[set_i]+""+nick+"\033[0m")
                else:
                    print("\033[33m|     |-[Не найдено]\033[0m")
            except:
                print("\033[33m|     |-[Не найдено]\033[0m")
            if set_i+1 == len(urls_site):break
            set_i += 1
        print(Fore.YELLOW + 'Продолжить?' + Style.RESET_ALL)
        print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
        while True:
            cont_input = input(Fore.GREEN + Style.BRIGHT + '/Sos/search_nick/>>> ' + Style.RESET_ALL + Style.NORMAL)
            if str(cont_input) == "y":
                cl()
            elif str(cont_input) == "n":
                print(Fore.YELLOW + 'Произвести выход из кода?' + Style.RESET)
                print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
                while True:
                    exit_input = input(Fore.GREEN + Style.BRIGHT + '/Sos/search_nick/>>> ' + Style.RESET_ALL + Style.NORMAL)
                    if str(exit_input) == "y":
                        cl()
                        credits.credits_services()
                    elif str(exit_input) == "n":
                        cl()
                    else:
                        wrn.warn.notthis_input()
            else:
                print(Fore.RED + Style.BRIGHT + 'Неккоретная команда' + Style.RESET_ALL + Style.NORMAL, f': {str(cont_input)}')
    except KeyboardInterrupt:
        warn.keyboard_interrupt()