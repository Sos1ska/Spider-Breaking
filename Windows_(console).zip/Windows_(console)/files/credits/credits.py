from colorama import Fore, Style, Back

def credits():
    print(Fore.YELLOW + 'Наши ВКонтакте профили' + Style.RESET_ALL, Fore.GREEN + '--->' + Style.RESET_ALL, Fore.BLUE + f'https://vk.com/nikitasos1ska\n'
    f'\t\t\thttps://vk.com/2pac_jdm\n'
    f'\t\thttps://vk.com/paket'
    f'\thttps://vk.com/covidone' + Style.RESET_ALL)
    print(Fore.YELLOW + 'Наша почта' + Style.RESET_ALL, Fore.GREEN + '--->' + Style.RESET_ALL, Fore.BLUE + 'soshack00@gmail.com' + Style.RESET_ALL)
    print(Fore.YELLOW + 'Наши' + Style.RESET_ALL, Fore.WHITE + 'Github' + Style.RESET_ALL, 'профили', Fore.GREEN + '--->' + Style.RESET_ALL, Fore.BLUE + f'https://github.com/Sos1ska\n'
    f'\t\t\thttps://github.com/Ki11sesh\n'
    f'\t\t\thttps://github.com/Cool-Hackers' + Style.RESET_ALL)