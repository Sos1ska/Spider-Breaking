import os, datetime

date_write = datetime.datetime.now()

def test_warn():
    print()
    os.system("clear")

def keyboard():
    FWW = open('Spider-Breaking\Termux\\files\log\log.txt', 'a',)
    FWW.write('root:Warning "KyboardInterrupt" - ' + str(date_write) + '\n')
    FWW.close()
    print('\nСохранено по пути Spider-Breaking/Termux/files/log/log.txt')
    quit()

def file_not_found():
    try:
        FWE = open('Spider-Breaking\Termux\\files\log\log.txt', 'a', encoding='utf-8')
    except FileNotFoundError:
        FWE1 = open('Spider-Breaking\Termux\\files\error.txt', 'a', encoding='utf-8')
        FWE1.write('root:Error "FileNotFoundError" - ' + str(date_write) + '\n')
        FWE1.close()
        print('\nСохранено по пути Spider-Brekaing/Termux/files/error.txt')
        quit()
    FWE.write('root:Error "FileNotFoundError" -')
    FWE.close()
    print('\nСохранено по пути Spider-Breaking/Termux/files/log/log.txt')
    quit()

def i_e_colo():
    FWE = open('Spider-Breaking\Termux\\files\log\log.txt', 'a', encoding='utf-8')
    FWE.write('root:ImportError "Colorama" - ' + str(date_write) + '\n')
    FWE.close()
    print('\nСохранено по пути Spider-Breaking/Termix/files/log/log.txt')
    quit()

def i_e_url_requ():
    FWE = open('Spider-Breaking\Termux\\files\log\log.txt', 'a', encoding='utf-8')
    FWE.write('root:ImportError "Requests" - ' + str(date_write) + '\n')
    FWE.close()
    print('\nСохранено по пути Spider-Breaking/Termux/files/log/log.txt')
    quit()

def i_e_url3():
    FWE = open('Spider-Breaking\Termux\\files\log\log.txt', 'a', encoding='utf-8')
    FWE.write('root:ImportError "Urllib3" - ' + str(date_write) + '\n')
    FWE.close()
    print('\nСохранено по пути Spider-Breaking/Termux/files/log/log.txt')
    quit()