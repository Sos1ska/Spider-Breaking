from time import sleep
import os

def Import_Error_Colorama():
    os.system("cls")
    print('У вас не установлен Colorama')
    sleep(5)

def Import_Error_Reuqests():
    os.system("cls")
    print('У вас не установлен Requests')
    sleep(5)

def Import_Error_Urllib3():
    os.system("cls")
    print('У вас не установлен Urllib3')
    sleep(5)

def keyboard_interrupt():
    os.system("cls")
    print('\t\t\tОшибка')
    print('Вы прожали CTRL+C, код выключится через 5 секунд')
    sleep(5)
    quit()