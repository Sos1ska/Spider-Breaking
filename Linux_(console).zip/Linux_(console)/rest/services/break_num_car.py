from.banner import banners
from.wrn_services import warn
from.credits import credits
from time import sleep
import os

try:
    import requests
except ImportError:
    warn.Import_Error_Reuqests()
try:
    import urllib3
except ImportError:
    warn.Import_Error_Urllib3()
try:
    import urllib.request
except ImportError:
    warn.Import_Error_Reuqests()
try:
    from colorama import Fore, Style, Back
except ImportError:
    warn.Import_Error_Colorama()

def start():
    try:
        os.system("clear")
        banners.banners.ban_num_car_services()
        credits.credits.credits_services()
        print(Fore.YELLOW + 'Введите номер авто' + Style.RESET_ALL)
        num_car_input = input(Fore.GREEN + '/Sos/break_num_car/>>> ' + Style.RESET_ALL)
        print('Проверьте эти ссылки')
        print(f"\t https://авто-история.рф/num/{str(num_car_input)}/")
        print(f"\t https://www.230km.ru/{str(num_car_input)}.nomer")
        print(f"\t http://avto-nomer.ru/ru/gallery.php?fastsearch={str(num_car_input)}")
        print(Fore.YELLOW + 'Продолжить?' + Style.RESET_ALL)
        print('y/n')
        while True:
            cont_input_4 = input(Fore.GREEN + Style.BRIGHT + '/Sos/break_num_car/>>> ' + Style.RESET_ALL + Style.NORMAL)
            if str(cont_input_4) == "n":
                os.system("clear")
                credits.credits.credits_services()
                print()
                print("Создатель кода", Fore.GREEN + "--->" + Style.RESET_ALL, Fore.BLUE + "https://vk.com/nikitasos1ska, https://github.com/Sos1ska" + Style.RESET_ALL)
                sleep(5)
                quit()
            elif str(cont_input_4) == "y":
                os.system("clear")
            else:
                print(Fore.RED + Style.BRIGHT + "Неккоретная команда" + Style.RESET_ALL + Style.NORMAL, f": {str(cont_input_4)}")
    except KeyboardInterrupt():
        warn.keyboard_interrupt()