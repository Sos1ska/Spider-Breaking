import os, time, datetime

date_write = datetime.datetime.now()

red = '\033[31m'
green = '\033[32m'
reset = '\033[39m'

def cl():
    os.system("cls")

def start_test():
    global cl
    try:
        try:
            FWS = open('Spider-Breaking\Windows\\files\log\log.txt', 'a', encoding='utf-8')
            FWT = open('Spider-Breaking\Windows\\files\\test\\test_log.txt', 'w', encoding='utf-8')
        except FileNotFoundError:
            print('Проверьте файлы по пути \n'
            'Spider-Breaking/Windows/files/log/log.txt\n'
            'Spider-Breaking/Windows/files/test/test_log.txt')
            time.sleep(10)
            quit()
        FWS.write('root:StartCode "test" - ' + str(date_write) + '\n')
        FWS.close()
        try:
            from files.main import test_main
            FWT.write(f'root:FileCode "main" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "main" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.credits.credits import credits
            FWT.write(f'root:FileCode "credits" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "credits" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.services.fix.fix_file import test_fix_file
            FWT.write(f'root:FileCode "fix_file" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "fix_file" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.services.warn.warn import test_warn
            FWT.write(f'root:FileCode "warn" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "warn" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.services.break_cell import test_break_cell
            FWT.write(f'root:FileCode "break_cell" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "break_cell" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.services.break_hosting import test_breaking_hosting
            FWT.write(f'root:FileCode "break_hosting" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "break_hosting" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.services.break_ip import test_break_ip
            FWT.write(f'root:FileCode "break_ip" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "break_ip" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.services.break_isp import test_break_isp
            FWT.write(f'root:FileCode "break_isp" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "break_isp" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.services.break_mac import test_break_mac
            FWT.write(f'root:FileCode "break_mac" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "break_mac" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.services.break_num import test_break_num
            FWT.write(f'root:FileCode "break_num" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "break_num" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.services.break_number_car import test_break_number_car
            FWT.write(f'root:FileCode "break_number_car" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "break_number_car" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from files.services.search_nick import test_search_nick
            FWT.write(f'root:FileCode "search_nick" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:FileCode "search_nick" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            from colorama import Fore, Style, Back
            FWT.write(f'\nroot:Component "Colorama" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'\nroot:Component "Colorama" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            import requests
            FWT.write(f'root:Component "Requests" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:Component "Requests" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        try:
            import urllib3
            FWT.write(f'root:Component "Urllib3" - {green}installed{reset} - ' + str(date_write) + '\n')
        except ImportError:
            FWT.write(f'root:Component "Urllib3" - {red}not installed{reset} - ' + str(date_write) + '\n')
            pass
        FWT.close()
        FRT = open('Spider-Breaking\Windows\\files\\test\\test_log.txt', 'r', encoding='utf-8')
        print(*FRT)
        time.sleep(12)
        cl()
    except KeyboardInterrupt:
        FWW = open('Spider-Breaking\Windows\\files\\test\\test_log.txt', 'a', encoding='utf-8')
        FWW.write('root:Warning "KeyboardInterrupt" - ' + str(date_write) + '\n')
        FWW.close()