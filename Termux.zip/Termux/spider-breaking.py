from files.test.test import start_test
from files.services.wrn.warn import keyboard, file_not_found
from files.main import start_main
import os, datetime, time

date_write = datetime.datetime.now()

def cl():
    os.system("clear")

try:
    try:
        FWS = open('Spider-Breaking\Termux\\files\log\log.txt', 'a', encoding='utf-8')
    except FileNotFoundError:
        file_not_found()
    FWS.write('root:StartCode "spider-breaking" - ' + str(date_write) + '\n')
    FWS.close()
    cl()
    start_test()
    cl()
    start_main()
except KeyboardInterrupt:
    keyboard()