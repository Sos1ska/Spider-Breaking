from time import sleep
from.ban import banners
from.services import break_number, break_num_car, break_ip, spy_vk, search_nick
from.help_input import help_go
from.credits import credits
from.errors import warn
import os

try:
    from colorama import Fore, Style, Back
except ImportError:
    warn.Import_Error_Colorama()

def cl():
    os.system("cls")

def start():
    try:
        cl()
        banners.start_code()
        cl()
        banners.main_banner()
        help_go.help()
        while True:
            services = input(Style.BRIGHT + Fore.GREEN + '/Sos/>>> ' + Style.RESET_ALL + Style.NORMAL)
            if str(services) == 'break_num':
                break_number.break_num()
            elif str(services) == 'break_ip':
                break_ip.break_ip()
            elif str(services) == 'break_num_car':
                break_num_car.break_go()
            elif str(services) == 'spy_vk':
                spy_vk.spy_go()
            elif str(services) == 'search_nick':
                search_nick.search_go()
            else:
                print(Fore.RED + Style.BRIGHT + 'Неккоретная команда' + Style.RESET_ALL + Style.NORMAL, f': {str(services)}')
    except KeyboardInterrupt:
        warn.keyboard_interrupt()