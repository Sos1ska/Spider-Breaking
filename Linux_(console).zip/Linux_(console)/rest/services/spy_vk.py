from.credits import credits
from.wrn_services import warn
from.banner import banners
from time import sleep
import os

def cl():
    os.system("clear")

try:
    import requests
except ImportError:
    warn.Import_Error_Reuqests()
try:
    import urllib.request
except ImportError:
    warn.Import_Error_Reuqests()
try:
    from colorama import Fore, Style, Back
except ImportError:
    warn.Import_Error_Colorama()
try:
    import urllib3
except ImportError:
    warn.Import_Error_Urllib3()

def start():
    try:
        banners.ban_spy_vk_services()
        credits.credits_services()
        print(Fore.YELLOW + 'Укажите ID Пользователя' + Style.RESET_ALL)
        iduser = input(Fore.GREEN + Style.BRIGHT + '>>> ' + Style.RESET_ALL + Style.NORMAL)
        print(Fore.YELLOW + 'Укажите токен ' + Style.RESET_ALL)
        token = input(Fore.GREEN + Style.BRIGHT + '>>> ' + Style.RESET_ALL + Style.NORMAL)
        r = requests.get("https://api.vk.com/method/newsfeed.getMentions?owner_id="+iduser+"&count=50&access_token="+token+"&v=5.50")
        datar = r.json()
        try:
            for pc in range(len(datar['response']['items'])):
                print("\033[36m|  |-[\033[33m"+str(pc)+"\033[36m]\033[32m https://vk.com/wall"+str(datar['response']['items'][pc]['to_id'])+"_"+str(datar['response']['items'][pc]['id'])+"\033[0m")
                print("\033[36m|  |\033[0m")
                try:
                    print("\033[36m|  |-[Text]: \033[32m"+str(datar['response']['items'][pc]['text'])+"\033[0m")
                except:
                    pass
                    print("\033[36m|\n|==|-[Result]:\033[32m", pc, "\033[0m")
        except:
            print('\033[31m|     |-Unkown error\033[0m')
            print('\033[31m|     |-Error inf:', datar, "\033[0m")
        print(Fore.YELLOW + 'Продолжить?' + Style.RESET_ALL)
        print(Fore.GREEN + Back.RED + 'y' + Style.RESET_ALL + Back.RESET, '/', Fore.RED + Back.GREEN + 'n' + Style.RESET_ALL + Back.RESET)
        while True:
            cont_spy_vk = input(Fore.GREEN + Back.RED + Style.BRIGHT + '/Sos/spy_vk/>>> ' + Style.RESET_ALL + Back.RED + Style.NORMAL)
            if str(cont_spy_vk) == "y":
                cl()
            elif str(cont_spy_vk) == "n":
                cl()
                credits.credits_services()
            else:
                print(Fore.RED + Style.BRIGHT + "Неккоретная команда" + Style.NORMAL + Style.RESET_ALL, f": {str(cont_spy_vk)}")
    except KeyboardInterrupt:
        wrn.warn.keyboardinterrupt()