from files.services.warn.warn import i_e_colo, file_not_found, i_e_url_requ, keyboard
from files.services.ban.banners import ban_ip
from files.credits.credits import credits
from time import sleep
import os, datetime, json

date_write = datetime.datetime.now()

def test_break_cell():
    print()
    os.system("clear")

Red = '\033[91m'
Green = '\033[92m'
Blue = '\033[94m'
Cyan = '\033[96m'
White = '\033[97m'
Yellow = '\033[93m'
Magenta = '\033[95m'
Grey = '\033[90m'
Black = '\033[90m'
Default = '\033[99m'
Underline = '\033[4m'
end       = '\033[0m'

try:
    from colorama import Fore, Style, Back
except ImportError:
    i_e_colo()

def cl():
    os.system("clear")

def start_cell():
    global cl
    try:
        try:
            FWS = open('Spider-Breaking\Windows\\files\log\log.txt', 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        cl()
        credits()
        FWS.write('root:StartCode "break_cell" - ' + str(date_write) + '\n')
        FWS.close()
        credits()
        latitude_tower_input = input(Yellow + "Введите широту: " + end)
        longitude_tower_input = input(Yellow + "Введите долготу: " + end)
        print(f"https://opencellid.org/#zoom=13&lat={str(latitude_tower_input)}&lon={str(longitude_tower_input)}")
        print()
        cont_input = input(Fore.GREEN + 'Нажмите [ENTER] для продолжения: ' + Style.RESET_ALL)
    except KeyboardInterrupt:
        keyboard()