import os, time

def keyboard_interrupt():
    os.system("cls")
    print('\t\t\tОшибка')
    time.sleep(1)
    print('Вы прожали CTRL+C, чтобы ошибка не повторилась, не нажимайте CTRL+C')
    time.sleep(5)

def file_not_found_error():
    os.system("cls")
    print('Проверьте есть ли папка по пути Windows_(console)/files/log')
    time.sleep(5)

def Import_Error_Colorama():
    os.system("cls")
    print('Произвести установку Colorama?')
    print('y/n')
    while True:
        install_colorama_input = input('>>> ')
        if str(install_colorama_input) == "y":
            os.system("pip install colorama")
        elif str(install_colorama_input) == "n":
            print('Код выключится через 5 секунд')
            time.sleep(5)
        else:
            print(f'Неккоретная команда: {str(install_colorama_input)}')

def Import_Error_Requests():
    os.system("cls")
    print('Произвести установку Requests')
    print('y/n')
    while True:
        install_requests_input = input('>>> ')
        if str(install_requests_input) == "y":
            os.system("pip install requests")
        elif str(install_requests_input) == "n":
            print('Код вылючится через 5 секунд')
            time.sleep(5)
            quit()
        else:
            print(f'Неккоретная команда: {str(install_requests_input)}')

def Import_Error_Urllib3():
    os.system("cls")
    print('Произвести установку Urllib3')
    print('y/n')
    while True:
        install_urllib3_input = input('>>> ')
        if str(install_urllib3_input) == "y":
            os.system("pip install urllib3")
        elif str(install_urllib3_input) == "n":
            print('Код выключится через 5 секунд')
            time.sleep(5)
            quit()
        else:
            print(f'Неккоретная команда: {str(install_urllib3_input)}')
    
def System_Error():
    os.system("cls")
    print('Ошибка под названием SystemError')
    time.sleep(5)
    quit()

def Syntax_Error():
    os.system("cls")
    print('Ошибка под названием SyntaxError')
    time.sleep(5)
    quit()

def Syntax_Warning():
    os.system("cls")
    print('Ошибка под названием SyntaxWarning')
    time.sleep(5)
    quit()

def System_Exit():
    os.system("cls")
    print('Ошибка под названием System_Exit')
    time.sleep(5)
    quit()

