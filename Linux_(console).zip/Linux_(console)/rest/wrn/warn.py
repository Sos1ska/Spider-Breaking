import os, time

def keyboard_interrupt():
    os.system("clear")
    print('\t\t\tОшибка')
    time.sleep(1)
    print('Вы прожали CTRL+C, чтобы ошибка не повторилась, не нажимайте CTRL+C')
    time.sleep(5)

def file_not_found_error():
    os.system("clear")
    print('Проверьте есть ли папка по пути Linux_(console)/files/log')
    time.sleep(5)

def Import_Error_Colorama():
    os.system("clear")
    print('У вас не установлен Colorama')

def Import_Error_Requests():
    os.system("clear")
    print('У вас не установлен Requests')

def Import_Error_Urllib3():
    os.system("clear")
    print('У вас не установлен Urllib3')
    
def System_Error():
    os.system("clear")
    print('Ошибка под названием SystemError')
    time.sleep(5)
    quit()

def Syntax_Error():
    os.system("clear")
    print('Ошибка под названием SyntaxError')
    time.sleep(5)
    quit()

def Syntax_Warning():
    os.system("clear")
    print('Ошибка под названием SyntaxWarning')
    time.sleep(5)
    quit()

def System_Exit():
    os.system("clear")
    print('Ошибка под названием System_Exit')
    time.sleep(5)
    quit()

